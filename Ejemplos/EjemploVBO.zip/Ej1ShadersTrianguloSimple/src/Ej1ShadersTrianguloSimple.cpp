//============================================================================
// Name        : Ej1ShadersTrianguloSimple.cpp
// Author      : Maikel
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

/* GLEW = GL + GLU */
#include <GL/glew.h>
/* Usamos la librería GLUT para la creación de la ventana */

#include <GL/glu.h>
#include <GL/glut.h>

/* Creamos una VARIABLE GLOBAL "PROGRAMA" que será una combinación
 * del vertex-shader y el fragment-shader
 */
GLuint program;

/* Creamos otra variable global para pasarle los vértices del triángulo
 * al vertex-shader. (las coordenadas que se le pasan como argumento al código shader)
 */
GLint attribute_coord2d;

int init_resources(void) {

	/* Nota: Variables para comprobar las compilaciones y linkados de los shaders */
	GLint compile_ok = GL_FALSE, link_ok = GL_FALSE;

	// --------------------------------------------/
	// ----------- VERTEX SHADER ------------------/
	GLuint vs = glCreateShader(GL_VERTEX_SHADER);
	const char *vs_source =
#ifdef GL_ES_VERSION_2_0
			"#version 100\n"  // OpenGL ES 2.0
#else
			"#version 120\n"  // OpenGL 2.1
#endif
			"attribute vec2 coord2d;                  "
			"void main(void) {                        "
			"  gl_Position = vec4(coord2d, 0.0, 1.0); "
			"}";
	glShaderSource(vs, 1, &vs_source, NULL);  // Nota: Enlazamos el código del vertex-shader.
	glCompileShader(vs);		  	//Nota: Compilamos el Shader
	glGetShaderiv(vs, GL_COMPILE_STATUS, &compile_ok);	//Nota: ¿Compilación OK?

	if (compile_ok == 0) {
		cerr << "Error al compilar el vertex shader\n";
		return 0;
	}

	// ----------------------------------------------/
	// ----------- FRAGMENT SHADER ------------------/
	GLuint fs = glCreateShader(GL_FRAGMENT_SHADER);
	const char *fs_source =
			"#version 120           \n"
			"void main(void) {        "
			"  gl_FragColor[0] = 0.0; "
			"  gl_FragColor[1] = 0.0; "
			"  gl_FragColor[2] = 1.0; "
			"}";
	glShaderSource(fs, 1, &fs_source, NULL);
	glCompileShader(fs);
	glGetShaderiv(fs, GL_COMPILE_STATUS, &compile_ok);
	if (!compile_ok) {
		cerr << "Error al compilar el fragment shader\n";
		return 0;
	}

	// ----------------------------------------------/
	// ----------- PROGRAMA SHADER ------------------/

	program = glCreateProgram(); // Creamos el programa Shader
	glAttachShader(program, vs); // Linkamos el vertex-shader al programa shader
	glAttachShader(program, fs); // Linkamos el fragment-shader al programa shader
	glLinkProgram(program); // Linkamos como programa shader el programa shader
	glGetProgramiv(program, GL_LINK_STATUS, &link_ok);
	if (!link_ok) {
		cerr << "glLinkProgram:";
		return 0;
	}

	// -----------------------------------------------------------/
	// ---- PASAR LOS VÉRTICES DEL TRIÁNGULO AL VERTEX-SHADER ----/

	const char* attribute_name = "coord2d"; // Nota: éste es el atributo ...
	attribute_coord2d = glGetAttribLocation(program, attribute_name); // ... a pasar como vértices del triángulo!!
	if (attribute_coord2d == -1) {
		cerr << "No se le pudo hacer bind al atributo " << attribute_name;
		return 0;
	}
	return 1;
}

void onDisplay() {
	  /* Limpiar el fondo -> ponerlo blanco */
	  glClearColor(1.0, 1.0, 1.0, 1.0);
	  glClear(GL_COLOR_BUFFER_BIT);

	  glUseProgram(program); // Nota: uso del programa shader "program"

	  glEnableVertexAttribArray(attribute_coord2d); // Nota: coordenadas del vertex-shader

	  // Nota: definimos los vértices de nuestro triángulo
	  GLfloat triangle_vertices[] = {
	     0.0,  0.8,
	    -0.8, -0.8,
	     0.8, -0.8,
	  };

	  /* Describe nuestro array de vértices a OpenGL (NO ES POSIBLE SABER DE ANTEMANO EL FORMATO :) ) */
	  glVertexAttribPointer(
	    attribute_coord2d, // atributo.
	    2,                 // número de elementos por vértice (aquí 2 por (x, y)).
	    GL_FLOAT,          // el tipo de cada elemento.
	    GL_FALSE,          // take our values as-is
	    0,                 // no hay datos extra entre cada posición
	    triangle_vertices  // puntero al array de C/C++
	  );

	  /* Empujar cada elemento en el buffer_vertices a el vertex-shader */
	  glDrawArrays(GL_TRIANGLES, 0, 3); // Nota: Dibuja los vértices especificados (el triángulo)
	  glDisableVertexAttribArray(attribute_coord2d);

	  /* Muestra el resultado */
	  glutSwapBuffers();
}

void free_resources() {
	// Liberamos los recursos reservados por los shaders
	glDeleteProgram(program);
}

int main(int argc, char* argv[]) {

	/* Funciones para inicializar Glut */
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGBA|GLUT_DOUBLE|GLUT_DEPTH);
	glutInitWindowSize(640, 480);
	glutCreateWindow("My First Triangle");

	/* Inicialiación / comprobación auxiliar gl + glu = glew */
	GLenum glew_status = glewInit();
	if (glew_status != GLEW_OK) {
		cerr << "Error: " << glewGetErrorString(glew_status);
		return EXIT_FAILURE;
	}

	/* Si no hubo errores, podemos inicializar los recursos.
	 * Nota: init_resources () devuelve 0 cuando ocurre algo no esperado!*/
	if (init_resources() == 1) {
		glutDisplayFunc(onDisplay);
		glutMainLoop();
	}

	free_resources(); // Cuando el programa "sale" de modo usual, liberla los recursos
	return EXIT_SUCCESS;
}
